const elementH1 = document.querySelector("H1");
const elementBtn = document.querySelector("button");
elementBtn.addEventListener("click",()=>{
    elementH1.textContent="เปลี่ยนข้อความเเล้ว";
})