const input = document.getElementById("score");
const sumbit = document.querySelector("button");
const grade = document.getElementById("grade");

sumbit.addEventListener("click", () => {
    const score = Number(input.value); 

    if (score >= 80) {
        grade.textContent = "Grade: A";
    } else if (score >= 70) {
        grade.textContent = "Grade: B";
    } else if (score >= 60) {
        grade.textContent = "Grade: C";
    } else if (score >= 50) {
        grade.textContent = "Grade: D";
    } else {
        grade.textContent = "Grade: E";
    }
});