const textarea = document.querySelector("textarea");
const b = document.querySelector("button");
const p = document.querySelector("p");

b.addEventListener("click", () => {
    p.textContent = "Character count:" + textarea.value.length;
})